package itaprojeto.test;

import static org.junit.Assert.assertTrue;

import java.util.List;

import org.dbunit.JdbcDatabaseTester;
import org.dbunit.util.fileloader.FlatXmlDataFileLoader;
import org.junit.Before;
import org.junit.Test;

import itaprojeto.execucao.UsuarioExecucao;
import itaprojeto.model.Usuario;

public class TesteUsuarioDAO {

	private String url = "jdbc:mysql://localhost:3306/coursera?useSSL=false&useTimezone=true&serverTimezone=UTC";
	private String user = "root";
	private String senha = "admin";

	private UsuarioExecucao ue = new UsuarioExecucao();
	private JdbcDatabaseTester jdt;

	private Usuario usuario;

	@Before
	public void setUp() throws Exception {
		jdt = new JdbcDatabaseTester("com.mysql.jdbc.Driver", url, user, senha);
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		jdt.setDataSet(loader.load("/scriptinicio.xml"));
		jdt.onSetup();

		// Prenche informa��es do Usuario que sera inserido para teste.
		usuario = new Usuario();
		usuario.setLogin("TesteInsercao");
		usuario.setEmail("teste@insercao.com");
		usuario.setNome("Usuario Teste Insercao");
		usuario.setSenha("1234565teste");
		usuario.setPontos("123");
	}

	/*
	 * Rank todos os usuarios.
	 */

	@Test
	public void rankingTodosUsuarios() {
		List<Usuario> usuarios = ue.ranking();
		assertTrue("Funcionou!", !usuarios.isEmpty());
	}

	/*
	 * Procura pelo primeiro usuario adicionado no XML.
	 */

	@Test
	public void recuperaUsuario() {
		Usuario primeiroUsuario = ue.recuperar("LUIZFO");
		assertTrue("Funcionou!", primeiroUsuario != null);
	}

	/*
	 * Adiciona o novo usuario e depois tenta recuperar lo para ver se foi
	 * adicionado com sucesso.
	 */

	@Test
	public void inserindoUsuario() {
		ue.inserir(usuario);
		assertTrue("Funcionou!", ue.recuperar("TesteInsercao") != null);
	}

	/*
	 * Adiciona pontos ao segundo usuario adicionado pelo xml.
	 */

	@Test
	public void adicionandoPontos() {
		ue.adicionarPontos("CARLINHOS1", 100);
	}

}
