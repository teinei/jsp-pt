package itaprojeto.execucao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import itaprojeto.dao.UsuarioDAO;
import itaprojeto.model.Usuario;

public class UsuarioExecucao implements UsuarioDAO {

	private String url = "jdbc:mysql://localhost:3306/coursera?useSSL=false&useTimezone=true&serverTimezone=UTC";
	private String user = "root";
	private String senha = "admin";


	static {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void inserir(Usuario u) {

		try (Connection c = DriverManager.getConnection(url, user, senha)) {

			String query = "INSERT INTO usuario(login, email, nome, senha, pontos) VALUES (?, ?, ?, ?,?);";
			PreparedStatement ps = c.prepareStatement(query);
			ps.setString(1, u.getLogin());
			ps.setString(2, u.getEmail());
			ps.setString(3, u.getNome());
			ps.setString(4, u.getSenha());
			ps.setString(5, u.getPontos());
			ps.executeUpdate();

		} catch (SQLException e) {
			System.out.println("Ocorreu um erro na execu��o.");
			e.printStackTrace();
		}

	}

	@Override
	public Usuario recuperar(String login) {

		try (Connection c = DriverManager.getConnection(url, user, senha)) {
			String query = "SELECT * FROM usuario WHERE login = ?;";
			PreparedStatement ps = c.prepareStatement(query);
			ps.setString(1, login);
			ResultSet resultSet = ps.executeQuery();

			Usuario usuario = new Usuario();

			if (resultSet.next()) {
				usuario.setLogin(login);
				usuario.setEmail(resultSet.getString("email"));
				usuario.setNome(resultSet.getString("nome"));
				usuario.setSenha(resultSet.getString("senha"));
				usuario.setPontos(resultSet.getString("pontos"));
			}
			return usuario;

		} catch (SQLException e) {
			System.out.println("Ocorreu um erro na execu��o.");
			e.printStackTrace();
			return null;
		}
	}

	@Override
	public void adicionarPontos(String login, int pontos) {
		try (Connection c = DriverManager.getConnection(url, user, senha)) {
			String query = "UPDATE usuario SET pontos = pontos + ? WHERE login = ?;";
			PreparedStatement ps = c.prepareStatement(query);
			ps.setInt(1, pontos);
			ps.setString(2, login);
			ps.executeUpdate();
		}

		catch (SQLException e) {
			e.printStackTrace();
		}

	}

	@Override
	public List<Usuario> ranking() {
		try (Connection c = DriverManager.getConnection(url, user, senha)) {

			String query = "SELECT * FROM usuario ORDER BY pontos DESC;";

			PreparedStatement ps = c.prepareStatement(query);
			ResultSet resultSet = ps.executeQuery();

			List<Usuario> usuarios = new ArrayList<>();

			while (resultSet.next()) {
				Usuario usuario = new Usuario();
				usuario.setLogin(resultSet.getString("login"));
				usuario.setEmail(resultSet.getString("email"));
				usuario.setNome(resultSet.getString("nome"));
				usuario.setSenha(resultSet.getString("senha"));
				usuario.setPontos(resultSet.getString("pontos"));
				usuarios.add(usuario);
			}

			return usuarios;

		} catch (SQLException e) {
			e.printStackTrace();
			return new ArrayList<>();
		}
	}

}
