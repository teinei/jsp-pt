package persistencia;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexaobd {

	public Connection conexao;//variavel da classe quando um metodo tentar acessar sempre sera esse mesmo valor
	
	public Connection getConexao()
	{
		
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		try {
			conexao = DriverManager.getConnection("jdbc:postgresql://localhost:5432/coursera", "coursera", "coursera");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conexao; 
	}
}