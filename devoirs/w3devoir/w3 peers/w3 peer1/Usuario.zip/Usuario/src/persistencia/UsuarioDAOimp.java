package persistencia;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Usuario;
import persistencia.Conexaobd;
public class UsuarioDAOimp implements UsuarioDAO {
	
	private Connection conexao;

	// criando a conexao
	public UsuarioDAOimp(){

		Conexaobd bd = new Conexaobd();
		conexao = bd.getConexao();

	}
	
	   //insere um novo usu�rio no banco de dados
	   public void inserir(Usuario u){
		   
		   String sql = "INSERT INTO usuario(login, email, nome, senha, pontos)"
					+ " values (?,?,?,?,?)";
			try {

			PreparedStatement stmt = conexao.prepareStatement(sql);

				stmt.setString(1, u.getLogin());
				stmt.setString(2, u.getEmail());
				stmt.setString(3, u.getNome());
				stmt.setString(4, u.getSenha());
				stmt.setInt(5, u.getPontos());
				stmt.execute();
				stmt.close();
				
			} catch (SQLException e) {
				e.printStackTrace();
			}		
	   }

	   
	 //adiciona os pontos para o usu�rio no banco
		public void adicionarPontos(String login, int pontos){
			String sql = "update usuario set pontos = pontos + ? where login = ?";
			try {
			PreparedStatement stmt = conexao.prepareStatement(sql);
			
			stmt.setInt(1, pontos);
			stmt.setString(2, login);
		
			
			stmt.execute();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		public List<Usuario> ranking() {

			String sql = "select * from usuario ORDER BY pontos DESC ";
			ArrayList<Usuario> usuarios = new ArrayList<Usuario>();

			try {
				PreparedStatement stmt = conexao.prepareStatement(sql);
				
				ResultSet rs = stmt.executeQuery();
				while(rs.next()) {
					Usuario usuario = new Usuario();
					usuario.setPontos(rs.getInt("pontos"));
					usuario.setEmail(rs.getString("email"));
					usuario.setNome(rs.getString("nome"));
					usuario.setLogin(rs.getString("login"));					
					usuarios.add(usuario);
				

				}
				stmt.close();
				return usuarios;

			} catch (Exception e) {
				e.printStackTrace();
			}

			return null;

		}
	   
		
		public Usuario recuperar(String login){
			
			String sql = "select * from usuario where login = ?" ; 
			
			try {
				
				PreparedStatement stmt = conexao.prepareStatement(sql);
				stmt.setString(1, login);
				ResultSet rs = stmt.executeQuery();
				if(rs.next()){
					
					Usuario usuario = new Usuario(); 
					
				usuario.setEmail(rs.getString("email"));
				usuario.setLogin(rs.getString("login"));
				usuario.setNome(rs.getString("nome"));
				usuario.setPontos(rs.getInt("pontos"));
			
				    
					return usuario;
				
				}			else{
					
					
					System.out.println("Nao encontrado");//so pra testar
				}
				
				stmt.close();
				
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			return null;
			}

		
	}
