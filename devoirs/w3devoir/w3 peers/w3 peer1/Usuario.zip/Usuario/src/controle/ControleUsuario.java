package controle;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import model.Usuario;
import persistencia.UsuarioDAOimp;

public class ControleUsuario {
	/*
	public ArrayList<Usuario> procura(String chave)
	    {
	    	///valida��es
	    	UsuarioDao dao = new UsuarioDao();
	    	return dao.pesquisa(chave);
	    }
	
	public Usuario pesquisaPeloId(Integer id)
	{
		///valida��es
    	UsuarioDao dao = new UsuarioDao();
    	return dao.pesquisaPorId(id);
	}
	
	public ArrayList<Usuario> procuracliente(String chave)
    {
    	///valida��es
    	UsuarioDao dao = new UsuarioDao();
    	return dao.pesquisacliente(chave);
    }

*/
	
	/*Retorna o usu�rio encontrado
	//Retorna null caso n�o tenha encontrado o usu�rio
	//ou caso n�o exista 
	public Usuario logarUsuario(String nome, String senha)
	{
		UsuarioDao dao = new UsuarioDao();
		Usuario usuario = dao.pesquisaUm(nome);
		if(usuario != null && usuario.getSenha().equals(senha) )
		
			return usuario;
		return null;
	}
	*/
	
	public boolean inserir(Usuario usuario)
	{
		//Faz valida��es
		UsuarioDAOimp dao = new UsuarioDAOimp();
		dao.inserir(usuario);
		return true;
	}
	
	public boolean adicionarPontos(Usuario usuario)
	{
		//Faz valida��es
		UsuarioDAOimp dao = new UsuarioDAOimp();
		//dao.adicionarPontos(usuario);
		return true;
	}
	
	public ArrayList<Usuario> ranking()
	{
		///valida��es
    	UsuarioDAOimp dao = new UsuarioDAOimp();
    	return dao.ranking();
	}
	
	/*public boolean excluir(Usuario usuario)
	{
		//Faz valida��es
		UsuarioDao dao = new UsuarioDao();
		dao.excluir(usuario);
		return true;
	}*/
	
	



}
