package testes;

import static org.junit.Assert.*;

import java.util.List;

import org.dbunit.JdbcDatabaseTester;
import org.dbunit.util.fileloader.FlatXmlDataFileLoader;
import org.junit.Before;
import org.junit.Test;

import model.Usuario;
import persistencia.UsuarioDAOimp;

public class DAOusuario {
	JdbcDatabaseTester jdt;
	@Before
	public void setUp() throws Exception {
		
		
		jdt = new JdbcDatabaseTester("org.postgresql.Driver", "jdbc:postgresql://localhost:5432/coursera", "coursera", "coursera");
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		jdt.setDataSet(loader.load("/testes/inicio.xml"));
		jdt.onSetup();
		
		
	}

	@Test
	public void recupera() {
		UsuarioDAOimp ud = new UsuarioDAOimp();		
	    Usuario usr = ud.recuperar("joao");
		assertEquals("joao", usr.getLogin());
		}

	@Test
	public void insere() {
		
		UsuarioDAOimp ud = new UsuarioDAOimp();			
	    Usuario usr = new Usuario();
	    usr.setEmail("luciano@gmail.com");
	    usr.setLogin("luciano");
	    usr.setNome("luciano bravo");
	    usr.setSenha("123456");
	    usr.setPontos(10);
	    ud.inserir(usr);
	    
	    assertNotNull(ud.recuperar("luciano"));
		}
	
	@Test
	public void adicionarPontos() {
		
		UsuarioDAOimp ud = new UsuarioDAOimp();		
		Integer pontoantigo = ud.recuperar("joao").getPontos();
		ud.adicionarPontos("joao",10);
		Integer pontonovo = pontoantigo + 10;
		assertEquals( pontonovo,  ud.recuperar("joao").getPontos());
		
	}
	@Test
	public void ranking() {
		UsuarioDAOimp ud = new UsuarioDAOimp();	
		List<Usuario> lista = ud.ranking();
		String p1 = lista.iterator().next().getLogin();
		assertEquals(2, lista.size());
		assertEquals("joao", p1);
		}
	
}
