import java.util.List;
/*
 * Classe Principal 
 * Implementa todas as funcionalidades solicitadas
 */

public class Principal {
	
	// Metodo principal da classe
	public static void main(String args[]){
		
		AcessaUsuario acessaDb = new AcessaUsuario();
		
		// 1 - Inserindo um usuario;
		Usuario u = new Usuario("joao","joao@email.com","Joao da Silva","joa123",3);
		acessaDb.inserir(u);
		
		// 2 - Consulta usuario por login;
		u = acessaDb.recuperar("pedro");
		System.out.println(u==null?"Nenhum usuario encontrado":u);
		
		// 3 - Atualiza ponto de usuario por login;
		acessaDb.adicionarPontos("joao", 5);
		u = acessaDb.recuperar("joao");
		System.out.println(u==null?"Nenhum usuario encontrado":u);
		
		// 4 - Lista todos usuarios do banco por ranking de pontos
		List<Usuario> uList;
		uList = acessaDb.ranking();
		uList.forEach(System.out::println);	
	}	
}
