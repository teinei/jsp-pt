import static org.junit.Assert.assertEquals;
import java.sql.SQLException;
import java.util.List;
import org.dbunit.Assertion;
import org.dbunit.JdbcDatabaseTester;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.util.fileloader.FlatXmlDataFileLoader;
import org.junit.Before;
import org.junit.Test;

public class TesteAcessoBancoDados {
	JdbcDatabaseTester jdt;
	AcessaUsuario acessaDb = new AcessaUsuario();
	
	// Set Up do banco de dados inicial em um arquivo XML
	@Before
	public void setUp() throws Exception {
		
		jdt = new JdbcDatabaseTester("org.postgresql.Driver","jdbc:postgresql://localhost/coursera","postgres","");
	    FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
	    jdt.setDataSet(loader.load("/testdb.xml"));
	    jdt.onSetup();
	    
	}
	
	// Teste insercao em banco de dados
		@Test
		public void TesteInserir() throws SQLException, Exception {
			Usuario u = new Usuario("joao","joao@email.com","Joao da Silva","jo123",6);
			acessaDb = new AcessaUsuario();
			acessaDb.inserir(u);
			IDataSet currentDataset = jdt.getConnection().createDataSet();
			ITable currentTable = currentDataset.getTable("USUARIO");
			FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
			IDataSet expectedDataset = loader.load("/verifica.xml");
			ITable expectedTable = expectedDataset.getTable("USUARIO");
			Assertion.assertEquals(expectedTable,currentTable);
		}	
	
	// Teste recuperar usuario por login
	@Test
	public void TesteRecuperar(){
			Usuario u;
			u = acessaDb.recuperar("pedro");
			assertEquals("pedro", u.getLogin());
			assertEquals("Pedro da Silva", u.getNome());
			assertEquals("pedro@email.com", u.getEmail());		
	}
	
	// Teste recuperar usuario por login
	@Test
	public void TesteAdicionarPontos(){
			Usuario u;
			acessaDb.adicionarPontos("pedro",7);
			u = acessaDb.recuperar("pedro");
			assertEquals(7, u.getPontos());
			
	}
	
	// Teste recuperar ranking de usuarios por pontos
			@Test
	public void TesteConsultaTodosUsuarios(){
			List<Usuario> uList;
			uList = acessaDb.ranking();
			assertEquals(7,uList.size());
			assertEquals("jose",uList.get(0).getLogin());
			assertEquals(2,uList.get(0).getPontos());
			assertEquals("luciana",uList.get(1).getLogin());
			assertEquals(3,uList.get(1).getPontos());
	}
	
	
}
