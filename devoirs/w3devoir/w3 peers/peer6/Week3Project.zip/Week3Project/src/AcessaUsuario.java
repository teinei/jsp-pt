import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/*
 * Classe que implementa o acesso ao banco de dados
 */
public class AcessaUsuario implements UsuarioDAO {

private String stSql;
PreparedStatement psStm;
	
	// Construtor da classe
	public AcessaUsuario() {
		   try {
			   Class.forName("org.postgresql.Driver");
	       }catch(ClassNotFoundException e){
	    	   e.printStackTrace();
	       }
	}
	
	// Retorna uma conexao com o banco de dados
	private Connection getConnection(){
		Connection c;
	    try{
	    	c = DriverManager.getConnection("jdbc:postgresql://localhost/coursera","postgres","");
		
		}catch(SQLException e){
			throw new RuntimeException("N�o foi poss�vel executar o acesso",e);
		}
		return c;	
	}	
	
	// Insere um usuario no banco de dados
	public void inserir(Usuario u) {
		stSql = "INSERT INTO usuario(login, email, nome, senha, pontos) VALUES (?, ?, ?, ?, ?);";
		try {
			psStm = getConnection().prepareStatement(stSql);
			psStm.setString(1, u.getLogin());
			psStm.setString(2, u.getEmail());
			psStm.setString(3, u.getNome());
			psStm.setString(4, u.getSenha());
			psStm.setInt(5, u.getPontos());
			int rs = psStm.executeUpdate();						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException("Erro ao inserir usuario",e);
		}		
	}

	// Recupera um usuario atarves do login
	public Usuario recuperar(String login) {
	stSql = "SELECT * FROM usuario WHERE login = ?;";
	try {
		psStm = getConnection().prepareStatement(stSql);
		psStm.setString(1, login);
		ResultSet rs = psStm.executeQuery();
		while(rs.next()){
			Usuario u = new Usuario(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));			
			return u;
		}
					
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		throw new RuntimeException("Erro ao consultar usuario",e);
	}
	return null;	
}

	// Adiciona pontos a um usuario existente
	public void adicionarPontos(String login, int pontos) {
		stSql = "UPDATE usuario SET pontos = ? WHERE login = ?";
		try {
			psStm = getConnection().prepareStatement(stSql);
			psStm.setInt(1, pontos);
			psStm.setString(2, login);
			int rs = psStm.executeUpdate();						
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException("Erro ao atualizar usuario",e);
		}				
	}

	// Lista todos os usuarios da base de dados
	public List<Usuario> ranking() {
		// TODO Auto-generated method stub
		List<Usuario> uList = new ArrayList<>();
		stSql = "SELECT * FROM usuario ORDER BY pontos DESC;";
		try {
			psStm = getConnection().prepareStatement(stSql);
			ResultSet rs = psStm.executeQuery();
			
			while(rs.next()){
				Usuario u = new Usuario(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getInt(5));			
				uList.add(u);
			}			
			uList = ordenaUsuario(uList);			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException("Erro ao atualizar usuario",e);
		}
		return uList;
	}

	// Ordena usuario em um ranking de pontos
	private List<Usuario> ordenaUsuario(List<Usuario> uList) {
		if(uList!=null)
			uList.sort((Usuario o1,Usuario o2)->o1.getPontos()-o2.getPontos());
		return uList;
	}
}
