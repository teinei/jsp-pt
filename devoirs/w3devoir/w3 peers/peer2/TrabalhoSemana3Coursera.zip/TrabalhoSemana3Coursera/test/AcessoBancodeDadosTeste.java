
import java.util.List;
import org.dbunit.Assertion;
import org.dbunit.JdbcDatabaseTester;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.util.fileloader.FlatXmlDataFileLoader;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import trabalhosemana3coursera.*;

public class AcessoBancodeDadosTeste {
    
       
     JdbcDatabaseTester jdt;
     UsuarioDAO dao;
        
    @Before
    public void setUp() throws Exception {
        jdt = new JdbcDatabaseTester("org.postgresql.Driver","jdbc:postgresql://localhost/coursera","postgres","Chemtech@2019-2");
        FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
        jdt.setDataSet(loader.load("/cargainicial.xml"));
        jdt.onSetup();
        dao = new UsuarioDAO();
    }
    
    @Test
    public void recuperaUsuario(){
        Usuario Han = dao.recuperar("Solo");
        assertEquals("Usuario{nome=Han Solo, pontos=9}", Han.toString());
        Usuario Skywalker = dao.recuperar("Luke");
        assertEquals("Usuario{nome=Luke Skywalker, pontos=8}", Skywalker.toString());
        Usuario Leia = dao.recuperar("Leia");
        assertEquals("Usuario{nome=Leia Organa, pontos=10}", Leia.toString());
     }
    
    @Test
    public void testeRanking() throws Exception{
        List<Usuario> rankeados = dao.ranking();
      
        assertEquals(3, rankeados.size());
        assertEquals("Leia",rankeados.get(0).getLogin());
        assertEquals("Solo",rankeados.get(1).getLogin());
        assertEquals("Luke",rankeados.get(2).getLogin());
    }
    
    @Test
    public void testeInserir() throws Exception{
        Usuario Lando = new Usuario("Calrissian");
        Lando.setNome("Lando Calrissian");
        Lando.setEmail("landocalrissian@bespin.com");
        Lando.setSenha("Falcon'sTrueOwner");
        Lando.setPontos(6);
        
        dao.inserir(Lando);
        
        IDataSet currentDataSet = jdt.getConnection().createDataSet();
        ITable currentTable = currentDataSet.getTable("USUARIO");
        FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
        IDataSet expectedDataset = loader.load("/novacarga.xml");
        ITable expectedTable = expectedDataset.getTable("USUARIO");
        Assertion.assertEquals(expectedTable, currentTable);
    }
    
    @Test
    public void testeUpdate(){
        dao.adicionarPontos("Solo", 1);
        assertEquals("Usuario{nome=Han Solo, pontos=10}",dao.recuperar("Solo").toString());
    }
}
   