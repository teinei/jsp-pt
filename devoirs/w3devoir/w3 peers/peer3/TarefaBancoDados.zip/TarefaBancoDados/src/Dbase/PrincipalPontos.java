package Dbase;

import java.sql.SQLException;

public class PrincipalPontos {

	public static void main(String[] args) throws SQLException {
		UsuarioDAO.adicionarPontos("ra", 7);
		UsuarioDAO.adicionarPontos("re", 11);

	}

}
