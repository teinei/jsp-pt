package Dbase;

import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

// Configura��o para acesso ao DB
public class UsuarioDAO {	
	static {
		try {
			Class.forName("org.postgresql.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	// Insere um novo usu�rio no banco de dados
	public static void inserir(Usuario u) throws SQLException {
		Connection conn = null;
		conn = DriverManager.getConnection("jdbc:postgresql://localhost/coursera", "postgres", "aluno231");					
		String sql = "INSERT INTO public.usuario(\r\n" + 
				"	login, email, nome, senha, pontos)\r\n" + 
				"	VALUES (?, ?, ?, ?, ?);";
		PreparedStatement stm = null;
		try {
			stm = conn.prepareStatement(sql);			
			stm.setString(1, u.getLogin());
			stm.setString(2, u.getEmail());
			stm.setString(3, u.getNome());			
			stm.setString(4, u.getSenha());
			stm.setInt(5, u.getPontos());
			stm.executeUpdate();
			System.out.println("Usu�rio cadastrado com sucesso !");
		} catch (SQLException e) {
			throw new RuntimeException ("N�o foi possivel executar o acesso ao DB.:", e);
		}		
	}
	
	// Recupera o usu�rio pelo seu login
	public static Usuario recuperar(String login) throws SQLException {			
		Connection conn = null;
		conn = DriverManager.getConnection("jdbc:postgresql://localhost/coursera", "postgres", "aluno231");				
		String sql = "SELECT * FROM usuario WHERE login = '"+ login +"'";
		PreparedStatement stm = null;			        
		ResultSet rs = null;
		try {
			stm = conn.prepareStatement(sql);
			rs = stm.executeQuery();
			if(!rs.next()) {
				System.out.println("N�o existe cadastro no DB com este login.: "+login);				
			} else {
				Usuario u = new Usuario();
				u.setLogin(rs.getString("login"));
				u.setEmail(rs.getString("email"));
				u.setNome(rs.getString("nome"));
				u.setSenha(rs.getString("senha"));
				u.setPontos(rs.getInt("pontos"));
				System.out.println(u.toString());
				}			 
		} catch (SQLException e) {
				throw new RuntimeException ("N�o foi possivel executar o acesso ao DB.:", e);
			} 
		return null;
	}
	
	// Adiciona/altera os pontos para o usu�rio no banco
	public static void adicionarPontos(String login, int pontos) throws SQLException {
			Connection conn = null;
			conn = DriverManager.getConnection("jdbc:postgresql://localhost/coursera", "postgres", "aluno231");
			PreparedStatement stm = null;
			PreparedStatement stm2 = null;
			ResultSet rs = null;
			// Consulta para saber se localizou algu�m no DB com o login
			String sql1 = "SELECT * FROM usuario WHERE login = '"+ login +"'";
			// Query de altera��o dos pontos com o login
			String sql = "UPDATE usuario SET pontos = ? WHERE login = '"+ login +"'";			
			try {				
				stm = conn.prepareStatement(sql1);
				rs = stm.executeQuery();
				if(!rs.next()) {
					System.out.println("N�o existe cadastro no DB com este login.: "+login);				
				} else {
					stm2 = conn.prepareStatement(sql);
					stm2.setInt(1, pontos);
					stm2.executeUpdate();
					System.out.println("Pontos alterado com sucesso para o login = "+login);
					}
			} catch (SQLException e) {
				throw new RuntimeException ("N�o foi possivel executar o acesso ao DB.:", e);
			}		
	}		
		
	// Retorna a lista de usu�rios ordenada por pontos (maior primeiro)
	public static List<Usuario> ranking() throws SQLException {
		List<Usuario> dados = new ArrayList<>();
		Connection conn = null;
		conn = DriverManager.getConnection("jdbc:postgresql://localhost/coursera", "postgres", "aluno231");
		PreparedStatement stm = null;		
		ResultSet rs = null;
		// Seleciona todas as colunas com registros existentes na tabela usuario em ordem decrescente
		String sql1 = "SELECT * FROM usuario ORDER BY pontos DESC";
		try {				
			stm = conn.prepareStatement(sql1);
			rs = stm.executeQuery();
			while(rs.next()) {
				Usuario u = new Usuario();
				u.setLogin(rs.getString("login"));
				u.setEmail(rs.getString("email"));
				u.setNome(rs.getString("nome"));
				u.setSenha(rs.getString("senha"));
				u.setPontos(rs.getInt("pontos"));
				dados.add(u);
			}
		} catch (SQLException e) {
			throw new RuntimeException ("N�o foi possivel executar o acesso ao DB.:", e);
		}
		return dados;
	}	
}
