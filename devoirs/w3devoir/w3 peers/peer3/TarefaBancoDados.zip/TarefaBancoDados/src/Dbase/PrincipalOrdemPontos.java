package Dbase;

import java.sql.SQLException;
import java.util.List;

public class PrincipalOrdemPontos {

	public static void main(String[] args) throws SQLException {
		List<Usuario> lista = UsuarioDAO.ranking();
		lista.forEach(System.out::println);

	}

}
