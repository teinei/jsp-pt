package Dbase;

import static org.junit.Assert.*;
import java.sql.SQLException;
import java.util.List;
import org.dbunit.Assertion;
import org.dbunit.JdbcDatabaseTester;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.util.fileloader.FlatXmlDataFileLoader;
import org.junit.Before;
import org.junit.Test;

public class TesteUsuarioDAO {
	
	JdbcDatabaseTester jdt;
	
	@Before
	public void setUp() throws Exception {
		jdt = new JdbcDatabaseTester("org.postgresql.Driver", "jdbc:postgresql://localhost/coursera", "postgres", "aluno231");		
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		jdt.setDataSet(loader.load("/listaRanking.xml"));
		jdt.onSetup();
	}

	@Test
	public void listaRanking() throws SQLException {
		System.out.println();
		System.out.println("Teste listaRanking executado abaixo:");
		List<Usuario> li = UsuarioDAO.ranking();
		li.forEach(System.out::println);
		assertEquals(2, li.size());  // Tamanho da lista DB
		assertEquals("ra", li.get(0).getLogin());  // Comparando para conferir se o primeiro registo � o login ra
	}
	
	@Test
	public void verificaLogin() throws Exception {
		System.out.println();
		System.out.println("Teste verificaLogin executado abaixo:");
		UsuarioDAO.recuperar("re");
		
		IDataSet currentDataset = jdt.getConnection().createDataSet(); // IDataSet Pega todos os dados DB
		ITable currentTable = currentDataset.getTable("USUARIO"); // Criar a tabela a partir do IDataSet
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();  // Ler arquivo xml
		IDataSet expectedDataset = loader.load("/listaRanking.xml");  // IDataSet para carregar no arquivo xml
		ITable expectedTable = expectedDataset.getTable("USUARIO"); // Recuperar os dados da  tabela
		Assertion.assertEquals(expectedTable, currentTable);  //  Compara expectedTable vs currentTable para ver se criou no BD
	}
	
	@Test
	public void alteraPontos() throws Exception {
		System.out.println();
		System.out.println("Teste alteraPontos executado abaixo:");
		UsuarioDAO.adicionarPontos("ra", 5);
				
		IDataSet currentDataset = jdt.getConnection().createDataSet(); // IDataSet Pega todos os dados DB
		ITable currentTable = currentDataset.getTable("USUARIO"); // Criar a tabela a partir do IDataSet
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();  // Ler arquivo xml
		IDataSet expectedDataset = loader.load("/alteraPontos.xml");  // IDataSet para carregar no arquivo xml
		ITable expectedTable = expectedDataset.getTable("USUARIO"); // Recuperar os dados da  tabela
		Assertion.assertEquals(expectedTable, currentTable);  //  Compara expectedTable vs currentTable para ver se criou no BD						
	}
	
	@Test
	public void cadastroNovo() throws Exception {
		System.out.println();
		System.out.println("Teste cadastroNovo executado abaixo:");		
		Usuario u = new Usuario();
		u.setLogin("du");
		u.setEmail("duda@gmail.com");
		u.setNome("Maria Eduarda");
		u.setSenha("duda");
		u.setPontos(12);		
		UsuarioDAO.inserir(u);
		
		IDataSet currentDataset = jdt.getConnection().createDataSet(); // IDataSet Pega todos os dados DB
		ITable currentTable = currentDataset.getTable("USUARIO"); // Criar a tabela a partir do IDataSet
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();  // Ler arquivo xml
		IDataSet expectedDataset = loader.load("/cadastroNovo.xml");  // IDataSet para carregar no arquivo xml
		ITable expectedTable = expectedDataset.getTable("USUARIO"); // Recuperar os dados da  tabela
		Assertion.assertEquals(expectedTable, currentTable);  //  Compara expectedTable vs currentTable para ver se criou no BD						
	}
}
