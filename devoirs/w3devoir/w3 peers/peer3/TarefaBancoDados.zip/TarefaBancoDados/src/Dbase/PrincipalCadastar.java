package Dbase;

import java.sql.SQLException;

public class PrincipalCadastar {

	public static void main(String[] args) throws SQLException {
		
		Usuario u = new Usuario();
		u.setLogin("ra");
		u.setEmail("raul@gmail.com");
		u.setNome("Raul Santiago");
		u.setSenha("raal");
		u.setPontos(10);
		
		UsuarioDAO.inserir(u);

	}

}
