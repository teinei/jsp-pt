/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import fontes.Usuario;
import fontes.UsuarioDB;
import java.sql.SQLException;
import java.util.List;
import org.dbunit.Assertion;
import org.dbunit.JdbcDatabaseTester;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.util.fileloader.FlatXmlDataFileLoader;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Dani
 */
public class TesteDB {
    
    JdbcDatabaseTester jdt;
    
    public TesteDB() {
    }
    
    @Before
    public void setUp() throws Exception {
        jdt = new JdbcDatabaseTester("com.mysql.jdbc.Driver","jdbc:mysql://mysqldb.c2figseifve5.sa-east-1.rds.amazonaws.com:3306/coursera","user","pass");
        FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
        jdt.setDataSet(loader.load("/inicio.xml"));
        jdt.onSetup();
        
    }
    
    @Test
    public void testeInserir() throws Exception
    {
        Usuario u = new Usuario("vanessa","vanessa@tal.com.br","Vanessa Soares","jklh",78);
        UsuarioDB db = new UsuarioDB();
        db.inserir(u);
  
        IDataSet currentDataset = jdt.getConnection().createDataSet();
        ITable currentTable = currentDataset.getTable("usuario");
        FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
        IDataSet expectedDataset = loader.load("/verificaInserir.xml");
        ITable expectedTable = expectedDataset.getTable("usuario");
        Assertion.assertEquals(expectedTable,currentTable);
        
       
    }
    
    @Test
    public void testeRecuperar() throws Exception
    {
        UsuarioDB db = new UsuarioDB();
        Usuario u = db.recuperar("Fulano");
        System.out.print(u);
        
        assertEquals("Fulano",u.getLogin());
        assertEquals("Fulano@tal.com.br",u.getEmail());
        assertEquals("Fulano de Tal",u.getNome());
        assertEquals("1234",u.getSenha());
        assertEquals(0,u.getPontos());
     
    }
  
    @Test
    public void testeAdicionarPontos() throws Exception
    {
        UsuarioDB db = new UsuarioDB();
        db.adicionarPontos("joao", 30);
  
        IDataSet currentDataset = jdt.getConnection().createDataSet();
        ITable currentTable = currentDataset.getTable("usuario");
        FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
        IDataSet expectedDataset = loader.load("/verificarPontos.xml");
        ITable expectedTable = expectedDataset.getTable("usuario");
        Assertion.assertEquals(expectedTable,currentTable);
        
       
    }
    
    @Test
    public void testeRanking() throws Exception
    {
        UsuarioDB db = new UsuarioDB();
        List<Usuario> lista = db.ranking();
  
        assertEquals(4,lista.size());
        assertEquals(65,lista.get(0).getPontos());
        assertEquals(33,lista.get(1).getPontos());
        assertEquals(15,lista.get(2).getPontos());
        assertEquals(0,lista.get(3).getPontos());
       
        
       
    }
}
