
package Model;

/**
 *
 * @author Raul Santiago
 */
public class Comentario {
    
    public int id_comentario;
    public String comentario;
    public String login_comentario;
    public int id_topico_comentario;
    public String fk_nomeUsuario;

    public int getId_comentario() {
        return id_comentario;
    }

    public void setId_comentario(int id_comentario) {
        this.id_comentario = id_comentario;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public String getLogin_comentario() {
        return login_comentario;
    }

    public void setLogin_comentario(String login_comentario) {
        this.login_comentario = login_comentario;
    }

    public int getId_topico_comentario() {
        return id_topico_comentario;
    }

    public void setId_topico_comentario(int id_topico_comentario) {
        this.id_topico_comentario = id_topico_comentario;
    }

    public String getFk_nomeUsuario() {
        return fk_nomeUsuario;
    }

    public void setFk_nomeUsuario(String fk_nomeUsuario) {
        this.fk_nomeUsuario = fk_nomeUsuario;
    }

    @Override
    public String toString() {
        return "Comentario{" + "id_comentario=" + id_comentario + ", comentario=" + comentario + ", login_comentario=" + login_comentario + ", id_topico_comentario=" + id_topico_comentario + ", fk_nomeUsuario=" + fk_nomeUsuario + '}';
    }
    
    
    
    
    
}
