
package Model;

/**
 *
 * @author Raul Santiago
 */
public class Topico {
    
    public int id_topico;
    public String titulo;
    public String conteudo;
    public String login;
    public String fk_nomeUsuario;

    public int getId_topico() {
        return id_topico;
    }

    public void setId_topico(int id_topico) {
        this.id_topico = id_topico;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getConteudo() {
        return conteudo;
    }

    public void setConteudo(String conteudo) {
        this.conteudo = conteudo;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getFk_nomeUsuario() {
        return fk_nomeUsuario;
    }

    public void setFk_nomeUsuario(String fk_nomeUsuario) {
        this.fk_nomeUsuario = fk_nomeUsuario;
    }

    @Override
    public String toString() {
        return "Topico{" + "id_topico=" + id_topico + ", titulo=" + titulo + ", conteudo=" + conteudo + ", login=" + login + ", fk_nomeUsuario=" + fk_nomeUsuario + '}';
    }

   
    
    
    
    
}
