
package Controller;

import Connection.UsuarioDAO;
import Connection.TopicoDAO;
import Model.Usuario;
import Model.Topico;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Raul Santiago
 */
@WebServlet(name = "cadastrotopico", urlPatterns = {"/cadastrotopico"})
public class CadastroTopicoServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String login = Usuario.user_current_login;
        String nomeUsuario = Usuario.user_current_nome;
        
        Topico t = new Topico();
        t.titulo = request.getParameter("titulo");
        t.conteudo = request.getParameter("conteudo");
        t.login = login;
        
        try {
            TopicoDAO.salvar(t);
            String fal = "false";
            request.setAttribute("fal", fal);            
            List<Topico> lista = TopicoDAO.exibirTopicos();
            request.setAttribute("nome", nomeUsuario);
            request.setAttribute("lista", lista);
            request.getRequestDispatcher("showtopicos.jsp").forward(request, response);
        } catch (IOException | SQLException | ServletException ex) {
            request.setAttribute("erro", ex.getMessage());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CadastroUsuarioServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    
}
