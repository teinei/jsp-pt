
package Controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Connection.UsuarioDAO;
import Model.Usuario;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Raul Santiago
 */
@WebServlet(name = "CadastroUsuarioServlet", urlPatterns = {"/cadastro"})
public class CadastroUsuarioServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {        
        
        Usuario u = new Usuario();
        u.login = request.getParameter("login");
        u.email = request.getParameter("email");
        u.nome = request.getParameter("nome");
        u.senha = request.getParameter("senha");
        u.pontos = 0;
        
        try {
            UsuarioDAO.salvar(u);
            String fal = "false";
            request.setAttribute("fal", fal);
            request.getRequestDispatcher("index.jsp").forward(request, response);
        } catch (IOException | SQLException | ServletException ex) {
            request.setAttribute("erro", ex.getMessage());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(CadastroUsuarioServlet.class.getName()).log(Level.SEVERE, null, ex);
        }        
    }

}