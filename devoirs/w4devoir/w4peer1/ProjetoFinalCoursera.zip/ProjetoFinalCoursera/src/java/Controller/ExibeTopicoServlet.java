
package Controller;

import Connection.ComentarioDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Connection.TopicoDAO;
import Model.Comentario;
import Model.Topico;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Raul Santiago
 */
@WebServlet(name = "exibetopico", urlPatterns = {"/exibetopico"})
public class ExibeTopicoServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp); 
    }    
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    
        String titulo = request.getParameter("titulo");
        String usuario = request.getParameter("name");
        
        try{
            Topico tp = TopicoDAO.buscaTopico(titulo, usuario);           
            request.setAttribute("id_topico", String.valueOf(tp.getId_topico()));
            request.setAttribute("titulo", tp.getTitulo());
            request.setAttribute("nomeU", tp.getFk_nomeUsuario());
            List<Comentario> lista = ComentarioDAO.exibirComentarios(tp.getId_topico());           
            request.setAttribute("lista", lista);
            request.setAttribute("conteudo", tp.getConteudo());
            request.getRequestDispatcher("topico.jsp").forward(request, response);
        } catch (ServletException ex){
             request.setAttribute("erro", ex.getMessage());            
        } catch (Exception ex) {
            Logger.getLogger(ExibeTopicoServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
  
}
