
package Controller;

import Connection.TopicoDAO;
import Connection.ComentarioDAO;
import Model.Comentario;
import Model.Topico;
import Model.Usuario;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 *
 * @author Raul Santiago
 */
@WebServlet(name = "cadastrocomentario", urlPatterns = {"/cadastrocomentario"})
public class CadastroComentarioServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String titulo = request.getParameter("titulo");
        String nome = request.getParameter("nome");
        String login = Usuario.user_current_login;
        Comentario c = new Comentario();
        c.comentario = request.getParameter("comentario");
        c.login_comentario = login;
        String id_topico = request.getParameter("id_top");
        c.id_topico_comentario = Integer.parseInt(id_topico);
        
         try{
            ComentarioDAO.salvar(c);
            List<Comentario> lista = ComentarioDAO.exibirComentarios(c.id_topico_comentario);
            Topico tp = TopicoDAO.buscaTopico(titulo, nome);
            request.setAttribute("id_topico", id_topico);
            request.setAttribute("lista", lista);
            request.setAttribute("titulo", tp.getTitulo());
            request.setAttribute("nomeU", tp.getFk_nomeUsuario());
            request.setAttribute("conteudo", tp.getConteudo());
            request.getRequestDispatcher("topico.jsp").forward(request, response);
        } catch (ServletException ex){
             request.setAttribute("erro", ex.getMessage());            
        } catch (Exception ex) {
            Logger.getLogger(ExibeTopicoServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

   
}
