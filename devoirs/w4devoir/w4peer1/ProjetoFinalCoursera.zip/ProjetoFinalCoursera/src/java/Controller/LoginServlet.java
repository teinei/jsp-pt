
package Controller;

import Connection.TopicoDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import Connection.UsuarioDAO;
import Model.Topico;
import Model.Usuario;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Raul Santiago
 */
@WebServlet(urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String login = request.getParameter("login");
        String senha = request.getParameter("senha");
        Usuario.user_current_login = login;
        UsuarioDAO a = new UsuarioDAO();               
        try {
            String nomeUsuario = a.autenticar(login, senha);
            Usuario.user_current_nome = nomeUsuario;
            if(nomeUsuario.equals("true")){                
                request.setAttribute("vdd", nomeUsuario);                
                request.getRequestDispatcher("index.jsp").forward(request, response);
            } else {
                List<Topico> lista = TopicoDAO.exibirTopicos();                
                request.setAttribute("nome", nomeUsuario);
                request.setAttribute("lista", lista);
                request.getRequestDispatcher("showtopicos.jsp").forward(request, response);
            }            
        } catch (IOException | SQLException | ServletException ex) {
            request.setAttribute("erro", ex.getMessage());
        } catch (Exception ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}