
package Controller;

import Connection.TopicoDAO;
import Model.Topico;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Raul Santiago
 */
@WebServlet(name = "showtopicos", urlPatterns = {"/showtopicos"})
public class ShowTopicosServlet extends HttpServlet {
    

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String nomeUsu = request.getParameter("nomeUsu");        
        List<Topico> lista;
        try {
            lista = TopicoDAO.exibirTopicos();
            request.setAttribute("nome", nomeUsu);
            request.setAttribute("lista", lista);
            request.getRequestDispatcher("showtopicos.jsp").forward(request, response);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(ShowTopicosServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

}
