
package Connection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import Model.Topico;
import Model.Usuario;
import java.util.ArrayList;
import java.util.List;

/**
 *@Objetivo Conectar com o DB para cadastrar e consultar os topicos
 * @author Raul Santiago
 */
public class TopicoDAO {
    
    // Cria uma lista dos tópicos a patir do banco de dados
    public static List<Topico> exibirTopicos() throws SQLException, ClassNotFoundException {
        List<Topico> todos = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        String sql = "select top.id_topico, top.titulo, top.conteudo, top.login, usu.nome from usuario usu join topico top on top.login = usu.login";
        conn = Conexao.getConexao();        
        try{
            stm = conn.prepareStatement(sql);
            rs = stm.executeQuery();
            while(rs.next()){
                Topico tp = new Topico();                
                tp.setId_topico(rs.getInt("id_topico"));
                tp.setTitulo(rs.getString("titulo"));
                tp.setConteudo(rs.getString("conteudo"));
                tp.setLogin(rs.getString("login"));
                tp.setFk_nomeUsuario(rs.getString("nome")); 
                todos.add(tp);
            }
        } catch (SQLException e) {
                throw new RuntimeException ("Não foi possivel executar o acesso ao DB. Erro: "+ e);
            } finally{
                    Conexao.fecharConexao(conn, stm, rs);
                }
        return todos;
    }
    
    
    // Busca um tópico para detalhar    
    public static Topico buscaTopico(String titulo, String nome) throws Exception {
        Connection conn = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        String sql = "select * from topico JOIN usuario ON usuario.login=topico.login where titulo= ? and nome= ?";
        conn = Conexao.getConexao();
        try{
            stm = conn.prepareStatement(sql);
            stm.setString(1, titulo);
            stm.setString(2, nome);
            rs = stm.executeQuery();
            if(rs.next()){
                Topico tp = new Topico();
                tp.setId_topico(rs.getInt("id_topico"));
                tp.setTitulo(rs.getString("titulo"));
                tp.setConteudo(rs.getString("conteudo"));
                tp.setLogin(rs.getString("login"));
                tp.setFk_nomeUsuario(rs.getString("nome"));
                return tp;
            } else {
                return null;
                }
        } catch (SQLException e) {
                throw new RuntimeException ("Não foi possivel executar o acesso ao DB. Erro: "+ e);
            }   finally{
                    Conexao.fecharConexao(conn, stm, rs);
                }        
    }
    
        
    // Insere um novo usuário no banco de dados
    public static void salvar(Topico t) throws SQLException, ClassNotFoundException {
        Connection conn = null;
        PreparedStatement stm = null;
        String sql = "INSERT INTO public.topico(\n" +
"	id_topico, titulo, conteudo, login)\n" +
"	VALUES (nextval('topico_id_topico_seq'), ?, ?, ?);";
        conn = Conexao.getConexao();
        try {
                stm = conn.prepareStatement(sql);
                stm.setString(1, t.getTitulo());
                stm.setString(2, t.getConteudo());
                stm.setString(3, t.getLogin());
                stm.executeUpdate();
        }   catch (SQLException e) {
                throw new RuntimeException ("Não foi possivel executar o acesso ao DB. Erro: "+ e);
            }   finally{
                    Conexao.fecharConexao(conn, stm);
                }
        
        ResultSet rs = null;        
        int pontosUsuario = 0;
        String log = Usuario.user_current_login;
        String sql1 = "select pontos from usuario where login='"+log+"';";
        conn = Conexao.getConexao();
        try{ 
            stm = conn.prepareStatement(sql1);
            rs = stm.executeQuery();
            while(rs.next()){                
                pontosUsuario = rs.getInt("pontos");
            }
        } catch (SQLException e) {
                throw new RuntimeException ("Não foi possivel executar o acesso ao DB. Erro: "+ e);
            }   finally{
                    Conexao.fecharConexao(conn, stm, rs);
                }
        
        pontosUsuario = pontosUsuario + 10;        
        String sql2 = "update usuario set pontos = "+pontosUsuario+" where login='"+log+"';";
        conn = Conexao.getConexao();
        try {
                stm = conn.prepareStatement(sql2);                
                stm.executeUpdate();
        }   catch (SQLException e) {
                throw new RuntimeException ("Não foi possivel executar o acesso ao DB. Erro: "+ e);
            }   finally{
                    Conexao.fecharConexao(conn, stm);
                }
    }
    
    
    
    
}
