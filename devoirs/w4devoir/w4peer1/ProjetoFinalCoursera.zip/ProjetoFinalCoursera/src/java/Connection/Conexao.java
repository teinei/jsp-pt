
package Connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Raul Santiago
 * @Objetivo para conectar e desconetctar do banco de dados com classes e constantes para agilizar o código
 */

public class Conexao {
	//atributos static para a conexao = uma constante
	//private static Connection conexao;
    private static final String DRIVER = "org.postgresql.Driver"; 	// comando para abrir a biblioteca do Postgres
    private static final String URL = "jdbc:postgresql://localhost/coursera";
    private static final String USER = "postgres";
    private static final String PASSWORD = "aluno231";
    
    static {
		try {
			Class.forName(DRIVER);
		} catch (ClassNotFoundException ex) { 
            Logger.getLogger(Conexao.class.getName()).log(Level.SEVERE, null, ex);
        } 
	}
    
    public static Connection getConexao() throws ClassNotFoundException
    {
        try
        {
            return (Connection) DriverManager.getConnection(URL, USER, PASSWORD);  //DriverManager.getConnection("jdbc:postgresql://localhost/coursera", "postgres", "aluno231");
        }
        catch(SQLException ex)
        {
            throw new RuntimeException("Algo errado com a conexão com o BD, erro: " + ex);
        }
    }
    
    public static void fecharConexao(Connection conn)
    {
        if(conn != null)//se o DB estiver conectado
        {
            try
            {
                conn.close();
            }
            catch(SQLException ex)
            {
                throw new RuntimeException("Algo errado com o fechamento da conexão com o BD, erro: " + ex);
            }
        }
    }
    
    public static void fecharConexao(Connection conn, PreparedStatement stmt)
    {
        if(stmt != null)
        {
            try
            {
                stmt.close();
            }
            catch(SQLException ex)
            {
                throw new RuntimeException("Algo errado com o fechamento da conexão com o BD, erro: " + ex);
            }
        }
        
        fecharConexao(conn);
    }
    
    public static void fecharConexao(Connection conn, PreparedStatement stmt, ResultSet rs)
    {
        if(rs != null)
        {
            try
            {
                rs.close();
            }
            catch(SQLException ex)
            {
                throw new RuntimeException("Algo errado com o fechamento da conexão com o BD, erro: " + ex);
            }
        }        
        fecharConexao(conn, stmt);
    }
    
}