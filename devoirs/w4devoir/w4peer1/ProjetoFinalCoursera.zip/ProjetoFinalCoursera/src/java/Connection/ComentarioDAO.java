
package Connection;

import Model.Comentario;
import Model.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Raul Santiago
 */
public class ComentarioDAO {
    
    // Insere um novo comentário no banco de dados
    public static void salvar(Comentario c) throws SQLException, ClassNotFoundException {
        Connection conn = null;
        PreparedStatement stm = null;
        String sql = "INSERT INTO public.comentario(\n" +
"	id_comentario, comentario, login, id_topico)\n" +
"	VALUES (nextval('comentario_id_comentario_seq'), ?, ?, ?);";
        conn = Conexao.getConexao();
        try {
                stm = conn.prepareStatement(sql);                
                stm.setString(1, c.getComentario());
                stm.setString(2, c.getLogin_comentario());
                stm.setInt(3, c.getId_topico_comentario());
                stm.executeUpdate();
        }   catch (SQLException e) {
                throw new RuntimeException ("Não foi possivel executar o acesso ao DB. Erro: "+ e);
            }   finally{
                    Conexao.fecharConexao(conn, stm);
                }
        
        ResultSet rs = null;        
        int pontosUsuario = 0;
        String log = Usuario.user_current_login;
        String sql1 = "select pontos from usuario where login='"+log+"';";
        conn = Conexao.getConexao();
        try{ 
            stm = conn.prepareStatement(sql1);
            rs = stm.executeQuery();
            while(rs.next()){
                pontosUsuario = rs.getInt("pontos");
            }
        } catch (SQLException e) {
                throw new RuntimeException ("Não foi possivel executar o acesso ao DB. Erro: "+ e);
            }   finally{
                    Conexao.fecharConexao(conn, stm, rs);
                }
        
        pontosUsuario = pontosUsuario + 3;
        String sql2 = "update usuario set pontos = "+pontosUsuario+" where login='"+log+"';";
        conn = Conexao.getConexao();
        try {
                stm = conn.prepareStatement(sql2);                
                stm.executeUpdate();
        }   catch (SQLException e) {
                throw new RuntimeException ("Não foi possivel executar o acesso ao DB. Erro: "+ e);
            }   finally{
                    Conexao.fecharConexao(conn, stm);
                }
        
        
    }
    
    
    
    // Cria uma lista dos comentários a patir do banco de dados
    public static List<Comentario> exibirComentarios(int id_topico) throws SQLException, ClassNotFoundException {
        List<Comentario> todos = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        String sql = "select id_comentario, comentario, comentario.login, comentario.id_topico, usuario.nome from ((comentario inner join topico on comentario.id_topico = topico.id_topico) inner join usuario on comentario.login = usuario.login) where comentario.id_topico="+id_topico+";";
        conn = Conexao.getConexao();        
        try{
            stm = conn.prepareStatement(sql);
            rs = stm.executeQuery();
            while(rs.next()){
                Comentario c = new Comentario();                
                c.setId_comentario(rs.getInt("id_comentario"));
                c.setComentario(rs.getString("comentario"));
                c.setLogin_comentario(rs.getString("login"));
                c.setId_topico_comentario(rs.getInt("id_topico"));
                c.setFk_nomeUsuario(rs.getString("nome"));
                todos.add(c);
            }
        } catch (SQLException e) {
                throw new RuntimeException ("Não foi possivel executar o acesso ao DB. Erro: "+ e);
            } finally{
                    Conexao.fecharConexao(conn, stm, rs);
                }
        return todos;
    }    
    
    
}