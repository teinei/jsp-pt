package Connection;

import Model.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * @Objetivo Conectar com o DB para cadastrar e consultar os dados do Usuario
 * @author Raul Santiago
 */
public class UsuarioDAO { 
       
    // Insere um novo usuário no banco de dados
    public static void salvar(Usuario u) throws SQLException, ClassNotFoundException {
        Connection conn = null;
        PreparedStatement stm = null;
        String sql = "INSERT INTO public.usuario(\r\n" + 
                        "	login, email, nome, senha, pontos)\r\n" + 
                        "	VALUES (?, ?, ?, ?, ?);";
        conn = Conexao.getConexao();
        try {
                stm = conn.prepareStatement(sql);
                stm.setString(1, u.getLogin());
                stm.setString(2, u.getEmail().toLowerCase());
                stm.setString(3, u.getNome().toUpperCase());
                stm.setString(4, u.getSenha());
                stm.setInt(5, u.getPontos());
                stm.executeUpdate();                
        }   catch (SQLException e) {
                throw new RuntimeException ("Não foi possivel executar o acesso ao DB. Erro: "+ e);
            }   finally{
                    Conexao.fecharConexao(conn, stm);
                }
    }
    
    // Autentica usuário no banco de dados através de login e senha
    public String autenticar(String login, String senha) throws Exception {        
        Usuario.user_current_login = login;        
        Connection conn = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        String sql = "select nome from usuario where login = ? and senha = ?";
        conn = Conexao.getConexao();
        try{
            stm = conn.prepareStatement(sql);
            stm.setString(1, login);
            stm.setString(2, senha);
            rs = stm.executeQuery();
            if(rs.next()){
                return rs.getString("nome");
            } else {
                return "true";
                }
        } catch (SQLException e) {
                throw new RuntimeException ("Não foi possivel executar o acesso ao DB. Erro: "+ e);
            }   finally{
                    Conexao.fecharConexao(conn, stm, rs);
                }
        
    }
    
    // Listar todos os usuários do DB
    public static List<Usuario> exibir() throws SQLException, ClassNotFoundException {
        List<Usuario> dados = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        String sql1 = "SELECT * FROM usuario";
        conn = Conexao.getConexao();
        try {
            stm = conn.prepareStatement(sql1);
            rs = stm.executeQuery();
            while(rs.next()) {
                Usuario u = new Usuario();
                u.setLogin(rs.getString("login"));
                u.setEmail(rs.getString("email"));
                u.setNome(rs.getString("nome"));                
                u.setPontos(rs.getInt("pontos"));                
                dados.add(u);
            }
        } catch (SQLException e) {
                throw new RuntimeException ("Não foi possivel executar o acesso ao DB.:", e);
        } finally{
                    Conexao.fecharConexao(conn, stm, rs);
        }
        return dados;
	}
    
    // Listar todos os usuários do DB por ordem de maiores pontuadores
    public static List<Usuario> ranking() throws SQLException, ClassNotFoundException {
        List<Usuario> eles = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stm = null;
        ResultSet rs = null;
        String sql1 = "SELECT login, email, nome, pontos FROM usuario where pontos >= 0 order by pontos desc";
        conn = Conexao.getConexao();
        try {
            stm = conn.prepareStatement(sql1);
            rs = stm.executeQuery();
            while(rs.next()) {
                Usuario u = new Usuario();
                u.setLogin(rs.getString("login"));
                u.setEmail(rs.getString("email"));
                u.setNome(rs.getString("nome"));
                u.setPontos(rs.getInt("pontos"));               
                eles.add(u);
            }
        } catch (SQLException e) {
                throw new RuntimeException ("Não foi possivel executar o acesso ao DB.:", e);
        } finally{
                    Conexao.fecharConexao(conn, stm, rs);
        }
        return eles;
	}
    
    
}