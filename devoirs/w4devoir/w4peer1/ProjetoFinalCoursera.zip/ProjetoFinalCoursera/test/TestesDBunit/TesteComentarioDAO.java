
package TestesDBunit;

import Connection.ComentarioDAO;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.sql.SQLException;
import java.util.List;
import org.dbunit.Assertion;
import org.dbunit.JdbcDatabaseTester;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.util.fileloader.FlatXmlDataFileLoader;
import Model.Comentario;


/**
 *
 * @author Raul Santiago
 */
public class TesteComentarioDAO {
    
    JdbcDatabaseTester jdt;
    
    @Before
    public void setUp() throws Exception {
        jdt = new JdbcDatabaseTester("org.postgresql.Driver", "jdbc:postgresql://localhost/coursera", "postgres", "aluno231");
        FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
        jdt.setDataSet(loader.load("/TestesDBunit/comentarios.xml"));
        jdt.onSetup();
    }
    
    
    @Test
    public void buscaComentario() throws SQLException, ClassNotFoundException {
            System.out.println();
            System.out.println("Teste buscaComentario executado abaixo:");
            List<Comentario> dados = ComentarioDAO.exibirComentarios(14);
            dados.forEach(System.out::println);
            assertEquals(3, dados.size());
            assertEquals("14", dados.get(0).getId_comentario());
    }
    
    
    @Test
    public void cadastroComentario() throws Exception {
            System.out.println();
            System.out.println("Teste cadastroComentario executado abaixo:");
            Comentario cm = new Comentario();
            cm.setId_comentario(21);
            cm.setComentario("Teste comentario"); 
            cm.setLogin_comentario("aa");
            cm.setId_topico_comentario(16);
            ComentarioDAO.salvar(cm);
            
            IDataSet currentDataset = jdt.getConnection().createDataSet(); 
            ITable currentTable = currentDataset.getTable("COMENTARIO"); 
            FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader(); 
            IDataSet expectedDataset = loader.load("/TestesDBunit/cadastroComentario.xml"); 
            ITable expectedTable = expectedDataset.getTable("COMENTARIO"); 
            Assertion.assertEquals(expectedTable, currentTable);
    }
    
    
    
}
