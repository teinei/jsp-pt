
package TestesDBunit;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;
import java.sql.SQLException;
import java.util.List;
import org.dbunit.Assertion;
import org.dbunit.JdbcDatabaseTester;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.util.fileloader.FlatXmlDataFileLoader;
import Connection.TopicoDAO;
import Model.Topico;

/**
 *
 * @author Raul Santiago
 */
public class TesteTopicoDAO {
    
    JdbcDatabaseTester jdt;
    
    @Before
    public void setUp() throws Exception {
        jdt = new JdbcDatabaseTester("org.postgresql.Driver", "jdbc:postgresql://localhost/coursera", "postgres", "aluno231");
        FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
        jdt.setDataSet(loader.load("/TestesDBunit/topicos.xml"));
        jdt.onSetup();
    }
    
    @Test
    public void listaTopicos() throws SQLException, ClassNotFoundException {
            System.out.println();
            System.out.println("Teste listaTopicos executado abaixo:");
            List<Topico> dados = TopicoDAO.exibirTopicos();
            dados.forEach(System.out::println);
            assertEquals(4, dados.size());
            assertEquals("14", dados.get(0).getLogin());
    }
    
     @Test
    public void verificaTopico() throws Exception {
            System.out.println();
            System.out.println("Teste verificaTopico executado abaixo:");
            Topico top = new Topico();
            top = TopicoDAO.buscaTopico("Educacao a Distancia", "EAD e a melhor solucao para quem nao tem disponibilidade de deslocamentos na cidade do Rio de Janeiro");
            top.toString();            
            assertEquals("14", top.getId_topico());
    }
    
    
    @Test
    public void cadastroTopico() throws Exception {
            System.out.println();
            System.out.println("Teste cadastroTopico executado abaixo:");
            Topico tp = new Topico();
            tp.setTitulo("Teste titulo");
            tp.setConteudo("Teste conteudo");
            tp.setLogin("aa");
            TopicoDAO.salvar(tp);
            
            IDataSet currentDataset = jdt.getConnection().createDataSet(); 
            ITable currentTable = currentDataset.getTable("TOPICO"); 
            FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader(); 
            IDataSet expectedDataset = loader.load("/TestesDBunit/cadastroTopico.xml"); 
            ITable expectedTable = expectedDataset.getTable("TOPICO"); 
            Assertion.assertEquals(expectedTable, currentTable);
    }
    
    
}
