
package TestesDBunit;

import org.junit.Test;
import static org.junit.Assert.*;
import java.sql.SQLException;
import java.util.List;
import org.dbunit.Assertion;
import org.dbunit.JdbcDatabaseTester;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.util.fileloader.FlatXmlDataFileLoader;
import org.junit.Before;
import Connection.UsuarioDAO;
import Model.Usuario;

/**
 *
 * @author Raul Santiago
 */
public class TesteUsuarioDAO {
    
    JdbcDatabaseTester jdt;
    
    @Before
    public void setUp() throws Exception {
        jdt = new JdbcDatabaseTester("org.postgresql.Driver", "jdbc:postgresql://localhost/coursera", "postgres", "aluno231");
        FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
        jdt.setDataSet(loader.load("/TestesDBunit/usuarios.xml"));
        jdt.onSetup();
    }
    
    @Test
    public void listaUsuarios() throws SQLException, ClassNotFoundException {
            System.out.println();
            System.out.println("Teste listaUsuarios executado abaixo:");
            List<Usuario> dados = UsuarioDAO.exibir();
            dados.forEach(System.out::println);
            assertEquals(6, dados.size());  // Tamanho da lista DB
            assertEquals("dn", dados.get(0).getLogin());  // Comparando para conferir se o primeiro registo é o login lua
    }
    
    
    
    @Test
    public void listaRanking() throws SQLException, ClassNotFoundException {
            System.out.println();
            System.out.println("Teste listaRanking executado abaixo:");
            List<Usuario> li = UsuarioDAO.ranking();
            li.forEach(System.out::println);
            assertEquals(6, li.size());  // Tamanho da lista DB
            assertEquals("lua", li.get(0).getLogin());  // Comparando para conferir se o primeiro registo é o login lua
    }
        
    @Test
    public void cadastroUsuario() throws Exception {
            System.out.println();
            System.out.println("Teste cadastroUsuario executado abaixo:");
            Usuario u = new Usuario();
            u.setLogin("du");
            u.setEmail("duda@gmail.com");
            u.setNome("MARIA EDUARDA");
            u.setSenha("duda");
            u.setPontos(12);
            UsuarioDAO.salvar(u);

            IDataSet currentDataset = jdt.getConnection().createDataSet(); 
            ITable currentTable = currentDataset.getTable("USUARIO"); 
            FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader(); 
            IDataSet expectedDataset = loader.load("/TestesDBunit/cadastroUsuario.xml"); 
            ITable expectedTable = expectedDataset.getTable("USUARIO"); 
            Assertion.assertEquals(expectedTable, currentTable);
    }
    
    @Test
    public void verificaLogin() throws Exception {
            System.out.println();
            System.out.println("Teste verificaLogin executado abaixo:");
            UsuarioDAO a = new UsuarioDAO();
            String nome = a.autenticar("dn", "123");
            assertEquals("DEISE NOGUEIRA", nome);
    }
    
}
