package br.com.webconversor.result;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Classe 'code behind' respons�vel pela l�gica da convers�o.
 * 
 * @author Luiz Foli
 * @since 20/12/2018
 *
 */

@WebServlet("/result")
public class Result extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

		PrintWriter writer = resp.getWriter();

		writer.println("<html>");
		writer.println("<head>");
		writer.println("<style>");
		writer.println("h1, p {text-align: center; font-family: monospace; color: #0b7e84;}");
		writer.println(".footer {width: 100%; bottom: 0; position: absolute;}");
		writer.println("</style>");
		writer.println("</head>");
		writer.println("<body>");

		if (req.getParameter("valor") == "" || req.getParameter("valor") == null || req.getParameter("opcao") == ""
				|| req.getParameter("opcao") == null) {

			writer.println("<h1>Necess�rio preencher as op��es corretamente.</h1>");

		}

		else {

			int valor = Integer.parseInt(req.getParameter("valor"));
			String opcao = req.getParameter("opcao");

			int resultado = (int) calculaConversao(opcao, valor);

			writer.println(
					"<h1 style='text-align:center;'>Resultado da Convers�o: </br>" + resultado + " " + opcao + "</h1>");
		}

		writer.println("<div class='footer'><p>@LuizFoli - Desenvolvedor Full Stack</p></div>");
		writer.println("</body>");
		writer.println("</html>");
	}

	/**
	 * M�todo respons�vel por converter Celsius para Fahrenheit ou vice-e-versa.
	 * 
	 * @author Luiz Foli
	 */
	private double calculaConversao(String opcao, int valor) {

		double retorno = 0;

		if (opcao.equalsIgnoreCase("F")) {

			retorno = (9 * valor / 5) + 32;

		} else {
			retorno = (valor - 32) / 1.8;
		}

		return retorno;
	}
}
