
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/Conversao"})
public class ConversorTemperaturaServlet extends HttpServlet {

   
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        double temperatura = Double.parseDouble(request.getParameter("temperatura"));
        String conversionType = request.getParameter("ConversionType");
        double resultadoConversao = 0;
        String tipoTemperaturaFinal = "Farenheit";
        
        response.setContentType("text/html;charset=UTF-8");
        switch(conversionType){
            case "CelsiusFarenheit":
                resultadoConversao = (temperatura*1.8) + 32;
                break;
            
                
            case "FarenheitCelsius":
                resultadoConversao = ((temperatura-32)*5)/9;
                tipoTemperaturaFinal = "Celsius";
                break;
        }
                
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Conversao</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>A temperatura em " + tipoTemperaturaFinal + " é :" + resultadoConversao +"º</h1>");
            out.println("<button onclick=\"history.back()\">Voltar</button");
            out.println("</body>");
            out.println("</html>");
        }
    }
}
