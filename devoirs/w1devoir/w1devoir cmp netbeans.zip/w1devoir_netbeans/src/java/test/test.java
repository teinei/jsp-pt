/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author java
 */
public class test {
    public static void main(String[] args){
        //
        SeleniumTest00 t1 = new SeleniumTest00();
        t1.setUp();
        t1.SeleniumTest();
        t1.tearDown();
    }
    
}
