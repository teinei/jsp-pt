package devoir;


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author aguinaldobarbosa
 */
@WebServlet(urlPatterns = {"/devoir/converter3"})
public class ConvertServlet3 extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String result = ""; //create 
        //get raw data from html
        String typeofConversion = request.getParameter("type");
        String svalor = request.getParameter("degrees");
        //convert html data to specific type
        double valor = 0.0;
        if(!(svalor.length()==0)) valor= Double.parseDouble(svalor);
        //svalor.isEmpty()
        response.setContentType("text/html;charset=UTF-8");
        //
        if(valor > 0.0){
            if(typeofConversion.equals("c2f")){ //c2f,F
                double t = (valor * 9) / 5 + 32;
                result = "The result of the conversion is : "+ t;
            } 
            //
            if(typeofConversion.equals("f2c")){ //f2c, C
                double t = (valor - 32) * 5 / 9;
                result = "The result of the conversion is : "+ t;
            }
        }
        //
        try(PrintWriter out = response.getWriter()) {
            //
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Resultado da conversão</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>"+ result + "</h1>");
            out.println("<a href='../index.html'>back home</a>");
            out.println("</body>");
            out.println("</html>");
        }
    }

}