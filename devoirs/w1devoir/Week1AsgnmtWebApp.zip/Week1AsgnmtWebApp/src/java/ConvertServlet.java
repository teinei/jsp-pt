
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author aguinaldobarbosa
 */
@WebServlet(urlPatterns = {"/converter2"})
public class ConvertServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String result = "";
        //response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            //
            String typeofConversion = request.getParameter("type");
            String svalor = request.getParameter("degrees");
            double valor = Double.parseDouble(svalor);
            if((!typeofConversion.equals("n")) && (valor > 0.0)){
               if(typeofConversion.equals("c2f")){ //c2f,F
                   double t = (valor * 9) / 5 + 32;
                   result = "The result of the conversion is : "+ t;
               } 
               
               if(typeofConversion.equals("f2c")){ //f2c, C
                   double t = (valor - 32) * 5 / 9;
                   result = "The result of the conversion is : "+ t;
               }
            } else if(svalor==null){
                //
                result ="display if nothing selected";
                //
            }
            
            //
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Resultado da conversão</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>"+ result + "</h1>");
            out.println("<h1>display if nothing selected</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

}