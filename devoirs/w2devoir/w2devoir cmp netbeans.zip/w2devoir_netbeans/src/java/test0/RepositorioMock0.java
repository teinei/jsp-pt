package test0;
// test/model/*.java
//

import model.IRepositorio;
import static org.junit.Assert.assertEquals;

/**
 *
 * @author Rafael Benzaquem Neto
 */
public class RepositorioMock0 implements IRepositorio {

    private String resultadoBuscarPlavra;
    private boolean buscarPalavraExecutado = false;

    public RepositorioMock0() {
    }

    @Override
    public String buscarPlavra(String chave) {
        this.buscarPalavraExecutado = true;
        return resultadoBuscarPlavra;
    }

    public void setResultadoBuscarPlavra(String resultadoBuscarPlavra) {
        this.resultadoBuscarPlavra = resultadoBuscarPlavra;
    }

    public void verificarBuscarPalavra(boolean foiExecutado) {
        assertEquals(foiExecutado, buscarPalavraExecutado);
    }

}
