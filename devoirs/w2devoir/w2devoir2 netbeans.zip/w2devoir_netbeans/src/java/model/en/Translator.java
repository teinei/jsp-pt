package model.en;

import model.*;

/*
    src/java/model/*.java
 */
public class Translator {

    private final IRepository repository;

    public Translator(IRepository repositorio) {
        repository = repositorio;
    }
    
    public String traduzir(String palavra) {
        //return repositorio.buscarPlavra(palavra);
        return repository.searchWord(palavra);
    }

}
