// src/java/model/*.java

package model.en;

import model.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Rafael Benzaquem Neto
 */
public class Repository implements IRepository {

    private String realPath = "arquivo.txt";

    public Repository() {
    }

    public Repository(String a_realPath) {
        realPath = a_realPath;
    }

    @Override
    //public String buscarPlavra(String chave)
    public String searchWord(String chave) {
        return sweepFile(chave);
    }
    
    //private String varrerArquivo(String chave)
    private String sweepFile(String chave) { //llave, clave, key /chavi/
        if (chave == null) {
            return null;
        }
        try {
            Scanner scan = new Scanner(new File(realPath));
            while (scan.hasNextLine()) {               
                    String linha[] = scan.nextLine().split(" ");
                    if (chave.equalsIgnoreCase(linha[0])) {
                        return linha[1];
                    } else if (chave.equalsIgnoreCase(linha[1])) {
                        return linha[0];
                    }               
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Repository.class.getName()).log(Level.SEVERE, null, ex);
        }

        return chave;
    }

}
