package model;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Rafael Benzaquem Neto
 */
public class TradutorTest {

    public TradutorTest() {
    }

    @Test
    public void traduzirSemString() {
        RepositorioMock repositorio = new RepositorioMock();
        Tradutor tradutor = new Tradutor(repositorio);
        
        repositorio.setResultadoBuscarPlavra("");
        
        String resultado = tradutor.traduzir("");
        assertEquals(resultado, "");
        
        repositorio.verificarBuscarPalavra(true);
    }

}
