import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/**
 * Tratando as regas de negócios para exibir no VIEW
 */
@WebServlet(urlPatterns = {"/traduzController"})
public class TraduzController extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String pal = request.getParameter("palavra");
        String p = pal.toUpperCase();
        String traducao = Traducao.traduzir(p);          
        request.setAttribute("palavra", p);
        request.setAttribute("traducao", traducao);
        if(p.equals(traducao)){
           String tipo = "true";
           request.setAttribute("tipo", tipo);
        }
        request.getRequestDispatcher("resposta.jsp").forward(request, response);
    }
}