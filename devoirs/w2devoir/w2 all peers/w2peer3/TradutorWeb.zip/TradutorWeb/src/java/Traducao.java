
import java.util.ResourceBundle;

/** 
 * Busca a palavra no arquivo de nome dicionario do tipo properties em português e inglês
 */
public class Traducao {
    
     private static final ResourceBundle dicio = ResourceBundle.getBundle("dicionario");
    
    public static String traduzir(String palavra){
        if(dicio.containsKey(palavra)){
            return dicio.getString(palavra);
        }else{
            return palavra;
        }
    }
    
}