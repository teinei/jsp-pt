import org.junit.Test;
import static org.junit.Assert.*;

public class TesteArmazenamento {    
    @Test
    public void TesteGetpalavra() {       
        
        Armazenamento arquivo = new Armazenamento("traducoes.xml");
        
        assertEquals("Hello", arquivo.getPalavraTraduzida("Ola"));
        assertEquals("Cat", arquivo.getPalavraTraduzida("Gato"));
    }
    
    @Test(expected=RuntimeException.class)
    public void TesteFicheiroNãoExiste() {              
        Armazenamento arquivo = new Armazenamento("ficheiro.xml");
    }
}