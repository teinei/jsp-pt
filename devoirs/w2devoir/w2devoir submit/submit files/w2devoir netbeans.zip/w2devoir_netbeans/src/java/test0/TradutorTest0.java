package test0;

/*
    test/model/*.java
 */
import model.*;
import test0.RepositorioMock0;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Rafael Benzaquem Neto
 */
public class TradutorTest0 {

    public TradutorTest0() {
    }

    @Test
    public void traduzirSemString() {
        RepositorioMock0 repositorio = new RepositorioMock0();
        Tradutor tradutor = new Tradutor(repositorio);
        
        repositorio.setResultadoBuscarPlavra("");
        
        String resultado = tradutor.traduzir("");
        assertEquals(resultado, "");
        
        repositorio.verificarBuscarPalavra(true);
    }

}
