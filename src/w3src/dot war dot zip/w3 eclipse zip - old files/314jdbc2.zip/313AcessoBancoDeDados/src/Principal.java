import java.util.List;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//
		//
		List<Usuario> lista = usuarioDAO.todosUsuarios();
		lista.forEach(System.out::println);
		//
		//
	}

}
