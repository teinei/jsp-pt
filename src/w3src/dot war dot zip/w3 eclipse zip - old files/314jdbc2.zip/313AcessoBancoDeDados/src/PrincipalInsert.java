
public class PrincipalInsert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//
		Usuario u = new Usuario();
		u.setLogin("duda");
		u.setNome("Maria Eduarda");
		u.setEmail("duda@gmail.com");
		//
		usuarioDAO.inserirUsuario(u);
		//
		//
	}

}
