package en;


import java.util.List;

public class main {
	//
	public static void main(String[] args) {
	//
	List<User> lista = userDAO.allUsers();
	lista.forEach(System.out::println);
	//
	//System.out.println("\n==> Advance For Loop Example..");
	/*
	for (String temp : crunchifyList) {
		System.out.println(temp);
	}
	*/
	//
	}
}
