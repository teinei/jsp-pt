package en;

public class MainInsert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//
		//
		String loginx="johnny",namex="NING ZHENG", emailx="johnny@escience.cn";
		//
		User u = new User();
		//
		u.setLogin(loginx);
		u.setName(namex);
		u.setEmail(emailx);
		//
		userDAO.insertUser(u);
		//
	}
}
