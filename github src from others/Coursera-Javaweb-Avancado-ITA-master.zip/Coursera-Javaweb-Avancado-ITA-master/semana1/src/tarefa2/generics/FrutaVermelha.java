package tarefa2.generics;

public class FrutaVermelha extends Fruta {

	public FrutaVermelha(String nome) {
		super(nome);
	}

	@Override
	public String toString() {
		return "FrutaVermelha [nome=" + nome + "]";
	}
}
