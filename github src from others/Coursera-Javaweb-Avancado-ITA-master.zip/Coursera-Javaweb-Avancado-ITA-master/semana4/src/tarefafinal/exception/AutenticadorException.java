package tarefafinal.exception;

public class AutenticadorException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 5504376142183667014L;

	public AutenticadorException(String msg) {
		super(msg);
	}
}
