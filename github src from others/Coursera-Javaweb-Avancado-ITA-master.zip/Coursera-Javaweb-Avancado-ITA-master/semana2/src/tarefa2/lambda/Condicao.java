package tarefa2.lambda;

public interface Condicao<E> {

	boolean incluir(E e);
}
