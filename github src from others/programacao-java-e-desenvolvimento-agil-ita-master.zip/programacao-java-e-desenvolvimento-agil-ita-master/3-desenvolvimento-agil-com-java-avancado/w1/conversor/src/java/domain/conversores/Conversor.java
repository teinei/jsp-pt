package domain.conversores;

public interface Conversor {
    double converter(double temperatura);
}
