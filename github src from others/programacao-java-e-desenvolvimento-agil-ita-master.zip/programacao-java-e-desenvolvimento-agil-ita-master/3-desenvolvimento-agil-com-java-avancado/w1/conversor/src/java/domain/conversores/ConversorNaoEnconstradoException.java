package domain.conversores;

public class ConversorNaoEnconstradoException extends RuntimeException {}
