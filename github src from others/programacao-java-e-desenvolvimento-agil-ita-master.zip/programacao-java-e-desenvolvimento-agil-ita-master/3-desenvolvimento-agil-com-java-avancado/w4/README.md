Olá, bem-vindo à Semana 4 do Curso 3 – Desenvolvimento Ágil com Java Avançado. Neste módulo você experimentará um exemplo prático de criação de aplicação Web MVC com acesso a Banco de Dados. Você também irá exercitar todo o conhecimento aprendido neste curso ao desenvolver uma aplicação Web com acesso a Banco de Dados e com gamificação! Solicito atenção à leitura sobre carga de trabalho neste módulo, que se encontra abaixo!

# Objetivos de aprendizado
- Criar aplicação Web com acesso a Banco de Dados com JDBC
- Criar aplicação Web com padrão MVC
- Criar Aplicação Web completa com JDBC e padrão MVC
- Classificar uma aplicação Web completa com acesso a Banco de Dados e padrão MVC

