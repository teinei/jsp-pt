Olá! Bem-vindo à semana 5 do curso Orientação a Objetos com Java! Nesta semana você aprofundará seu contato com os conceitos de Encapsulamento, Acoplamento entre Classes e Interfaces em Java. Ao final desta semana, você será capaz de 1) projetar e estruturar programas Java evitando quebras de encapsulamento e propiciando acoplamento baixo entre classes, 2) além de garantir acoplamento abstrato entre classes pelo uso adequado de interfaces em Java


