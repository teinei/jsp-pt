# Semana 1

Neste módulo você será capaz de identificar, definir e diferenciar os conceitos básicos de orientação a objetos, tanto em teoria quanto em Java: classes, objetos, atributos de classes, construtores de classes, responsabilidades, colaborações e cartões CRC
