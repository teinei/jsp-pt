package mecanica.embaralhador;

public interface Embaralhador {
    String embaralhar(String palavra);
}
