lá! Bem-vindo à Semana 4 do curso sobre TDD! Nesta semana você aprofundará seu contato teórico e prático com técnicas de refatoração. Ao final desta semana, você será capaz de identificar alguns dos principais tipos de mau cheiro e aplicar técnicas de refatoração apropriadas para remoção segura desses maus cheiros.

