public class ProblemaHardwareException extends Exception {
    public ProblemaHardwareException() {
        super("Houve um problema no hardware");
    }
}