Olá! Bem-vindo à Semana 3 do curso sobre TDD! Nesta semana você aprofundará seu contato prático com casos de teste e com dependências entre classes no contexto do TDD. Ao final desta semana, você será capaz de:
- 1) modelar casos de teste a partir de responsabilidades para uso no ciclo TDD;
- 2) testar classes com dependências por meio de mock objects.
