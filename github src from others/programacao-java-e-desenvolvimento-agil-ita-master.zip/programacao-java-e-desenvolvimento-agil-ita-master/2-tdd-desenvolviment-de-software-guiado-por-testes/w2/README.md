Olá! Bem-vindo à Semana 2 do curso sobre TDD! 
Nesta semana você aprofundará seu contato prático com o TDD, bem como com o ciclo de Refatoração. Ao final desta semana, você será capaz de: 

- 1) modelar uma classe com o TDD, entendendo os princípios que estão por trás; 
- 2) entender o papel do mau cheiro" no Ciclo da Refatoração!
