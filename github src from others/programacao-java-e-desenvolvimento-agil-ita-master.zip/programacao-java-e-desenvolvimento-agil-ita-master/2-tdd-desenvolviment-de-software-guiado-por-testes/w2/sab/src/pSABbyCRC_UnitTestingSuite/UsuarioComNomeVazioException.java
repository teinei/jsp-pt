package pSABbyCRC_UnitTestingSuite;

@SuppressWarnings("serial")
public class UsuarioComNomeVazioException extends Exception {
    public UsuarioComNomeVazioException(String message)
    {
        super(message);
    }
}