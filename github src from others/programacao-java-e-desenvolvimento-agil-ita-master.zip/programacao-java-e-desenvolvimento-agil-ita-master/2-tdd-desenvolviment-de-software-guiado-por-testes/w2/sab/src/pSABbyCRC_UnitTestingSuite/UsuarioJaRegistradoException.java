package pSABbyCRC_UnitTestingSuite;

@SuppressWarnings("serial")
public class UsuarioJaRegistradoException extends Exception {
    public UsuarioJaRegistradoException(String message)
    {
        super(message);
    }
}