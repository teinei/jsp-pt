package pSABbyCRC_UnitTestingSuite;

@SuppressWarnings("serial")
public class LivroIndisponivelParaEmprestimoException extends Exception {
    public LivroIndisponivelParaEmprestimoException(String message)
    {
        super(message);
    }
}