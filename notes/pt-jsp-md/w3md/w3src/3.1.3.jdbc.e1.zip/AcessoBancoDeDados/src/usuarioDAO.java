import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class usuarioDAO {
	//
	static {
		//
		try{
			//
			Class.forName("org.postgresql.Driver");
			//
		} catch (ClassNotFoundException e) {
			//
			e.printStackTrace();
			//
		}
		//
	}
	//
	public static List<Usuario> todosUsuarios(){
	    List<Usuario> todos = new ArrayList<>();
	    //
	    try(Connection c = DriverManager.getConnection(
	    		"jdbc:postgresql://localhost/usuarios","postgres","admin")){
	    	//
	    	//
	    }catch(SQLException e){
	    	//
	    	throw new RuntimeException("Nao foi possivel acess", e);
	    	//
	    }
	    //
	    return todos;
	}
	//
}
