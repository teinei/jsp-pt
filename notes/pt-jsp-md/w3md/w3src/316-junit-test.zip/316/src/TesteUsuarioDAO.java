import static org.junit.Assert.*;

import java.util.List;

import org.dbunit.JdbcDatabaseTester;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.util.fileloader.FlatXmlDataFileLoader;
import org.junit.Before;
import org.junit.Test;

public class TesteUsuarioDAO {
	//
	//
	JdbcDatabaseTester jdt;
	//
	@Before
	public void setUp() throws Exception {
		//
		jdt = new JdbcDatabaseTester("org.ostgresql.Driver","jdbc:postgresql://localhost/usuarios","postgres","crimson");
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		jdt.setDataSet(loader.load("/inicio.xml"));
		jdt.onSetup();
		//
	}

	@Test
	public void recueraTodos() {
		//
		List<Usuario> lista = usuarioDAO.todosUsuarios();
		assertEquals(2, lista.size());
		assertEquals("joao", lista.get(0).getLogin());	
		//
	}
	//
	@Test
	public void insereNovo() throws Exception {
		//
		Usuario u = new Usuario();
		u.setLogin("duda");
		u.setNome("Maria Eduarda");
		u.setEmail("duda@gmail.com");
		//
		usuarioDAO.inserirUsuario(u);
		//
		IDataSet currentDataset = jdt.getConnection().createDataSet();
		ITable currentTable = currentDataset.getTable("usuario");
		FlatXmlDataFileLoader loader = new FlatXmlDataFileLoader();
		IDataSet expectedDataset = loader.load("/verifica.xml");
		ITable expectedTable = currentDataset.getTable("usuario");
		assertEquals(expectedTable, currentTable);
		//jdt.setDataSet(loader.load("/inicio.xml"));
		//
		//
		//
	}
	//
	//
	//
	public void test() {
		fail("Not yet implemented");
	}

}
