import java.util.List;

public class Principal {
	//pricipal, main
	public static void main(String[] args) {
		//
		//
		List<Usuario> lista = usuarioDAO.todosUsuarios();
		//usuario, user, usuário, u:zu.aa.Rio
		//todos, all
		lista.forEach(System.out::println);
		//
		//
	}

}
